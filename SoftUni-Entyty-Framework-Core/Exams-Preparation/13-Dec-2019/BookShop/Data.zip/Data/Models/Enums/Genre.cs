﻿
namespace BookShop.Data.Models.Enums
{
    using System;
    public enum Genre
    {
        Biography = 1,
        Business = 2,
        Science = 3
    }
}
