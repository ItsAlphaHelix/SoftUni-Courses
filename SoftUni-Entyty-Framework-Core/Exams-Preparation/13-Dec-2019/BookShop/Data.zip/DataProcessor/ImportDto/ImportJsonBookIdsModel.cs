﻿
namespace BookShop.DataProcessor.ImportDto
{
    public class ImportJsonBookIdsModel
    {
        public int? Id { get; set; }
    }
}